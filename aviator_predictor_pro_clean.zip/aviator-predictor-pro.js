import express from 'express';
import * as tf from '@tensorflow/tfjs-node';

const app = express();
const PORT = 3000;

const historicoVoos = [
  { horario: "10:00", multiplicador: 2.1 },
  { horario: "10:05", multiplicador: 3.5 },
  { horario: "10:10", multiplicador: 1.8 },
  { horario: "10:15", multiplicador: 4.2 },
  { horario: "10:20", multiplicador: 2.9 },
];

const horarios = historicoVoos.map(v => parseInt(v.horario.replace(':', '')));
const multiplicadores = historicoVoos.map(v => v.multiplicador);

const model = tf.sequential();
model.add(tf.layers.dense({ units: 8, inputShape: [1], activation: 'relu' }));
model.add(tf.layers.dense({ units: 1 }));

model.compile({ optimizer: 'adam', loss: 'meanSquaredError' });

const xs = tf.tensor2d(horarios, [horarios.length, 1]);
const ys = tf.tensor2d(multiplicadores, [multiplicadores.length, 1]);

(async () => {
  await model.fit(xs, ys, { epochs: 50 });
})();

async function preverHorario(agora) {
  const input = tf.tensor2d([[parseInt(agora.replace(':', ''))]]);
  const output = await model.predict(input).data();
  return output[0];
}

app.get('/api/sinais', async (req, res) => {
  const agora = new Date();
  const horaAgora = agora.getHours().toString().padStart(2, '0') + ':' + agora.getMinutes().toString().padStart(2, '0');
  
  const previsao = await preverHorario(horaAgora);
  
  res.json({
    horarioAtual: horaAgora,
    sinalPrevisto: previsao.toFixed(2),
    recomendacao: previsao > 2 ? 'Entrar forte' : 'Cautela'
  });
});

app.use(express.static('public'));

app.listen(PORT, () => {
  console.log(`Servidor Aviator Predictor PRO rodando na porta ${PORT}`);
});